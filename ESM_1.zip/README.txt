Online Resource 1
Maneuver-Aware History and Ordered Directional Lane Representations for Multimodal Trajectory Prediction at Urban Intersections
Journal: Applied Intelligence
Authors: Jianhua Zhang; Shichang Zhang
Affiliation: College of Civil Engineering and Transportation, Northeast Forestry University, Harbin 150040, China
Corresponding author: Jianhua Zhang; jhzhang609@nefu.edu.cn

Caption: Scenario-ID lists for the AV2 intersection training, validation, and test partitions.
Data source: https://www.argoverse.org/av2.html
The lists identify the subsets defined in Section 5.1. They do not contain AV2 trajectories, maps, annotations, model weights, or model source code.
Each plain-text list has one scenario ID per line. train, val, and test refer to the corresponding original AV2 partitions.
Counts: train 60,899; validation 7,627; test 7,704. The three lists are disjoint.
Use the AV2 data under the terms provided by its original distributor.
Checksums are provided in SHA256SUMS.txt.
